# Turtle Escape - Activity 1.2.4
# Authors: Vivek Kasireddy, Abdul ElHout
# Date: 12/8/2021 


# Import turtle to initiate the functions
import turtle as trtl
 
# Import turtle as random to help randomize
import random as rand
 
#----- Game Configurations -----#
num_walls = 25
path_width = 23
wall_color = "purple"
 
# Configurations for maze turtle
maze_writer = trtl.Turtle()
maze_writer.color(wall_color)
maze_writer.pensize(5)
maze_writer.speed("fastest")
maze_writer.penup()
maze_writer.goto(path_width*2, -path_width*2)
maze_writer.pendown()

# configurations for the maze runner
maze_runner = trtl.Turtle(shape="turtle")
maze_runner.fillcolor("green")
maze_runner.penup()
maze_runner.goto(-path_width*2, path_width*2)
maze_runner.pendown()

# ----- Functions ----- #
# TODO: define all functions needed for the program to run 
# this includes the doors, barriers, and the maze runner 

# define function for door
def draw_door(pos):
   maze_writer.forward(pos)
   if (rand.randint(0,2)<=1):
     maze_writer.penup()
   maze_writer.forward(path_width*2)
   maze_writer.pendown()
 
# define function for barrier
def draw_barrier(pos):
   maze_writer.forward(pos)
   if (rand.randint(0,4)<=2):
     maze_writer.left(90)
     maze_writer.forward(path_width*2)
     maze_writer.back(path_width*2)
     maze_writer.right(90)

# define the maze runner 
# make the maze runner move forward 
def go_runner():
  maze_runner.forward(10)
  wn_canvas = wn.getcanvas()
  x,y  = maze_runner.position()
  margin = 10
  items = wn_canvas.find_overlapping(x+margin, -y+margin, x-margin, -y-margin)

# check canvas is not empty
  if (len(items) > 0):
        canvas_color = wn_canvas.itemcget(items[0], "fill")
        if (canvas_color == wall_color):
# if the maze runner hit the walls, then the game is stopped and the maze runner can not move anymore
            maze_runner.fillcolor("red")
            wn.onkeypress(None, 'w')
            return
# define the different functions for the directions the maze runner can go 
def go_up():
  maze_runner.setheading(90)
def go_down():
  maze_runner.setheading(270)
def go_left():
  maze_runner.setheading(180)
def go_right():
  maze_runner.setheading(0)


# draw the maze from the middle out
wall_length = path_width

# set a for loop and range function to iterate the dsired number of times
for w in range (num_walls):
 wall_length += path_width
 if w > 4:

# TODO: randomize the door and barrier
     maze_writer.left(90)
     door = rand.randint(path_width*2,(wall_length - path_width*2))
     barrier = rand.randint(path_width*2,(wall_length - path_width*2))
# the door is drawn first, then the barrier
     while abs(door-barrier) < path_width:
       door = rand.randint(path_width*2,(wall_length - path_width*2))
# door first
     if door < barrier:
       draw_door(door)
# draw the barrier
# subtract the door lengths that are already drawn
       draw_barrier(barrier - door - path_width*2)
       maze_writer.forward(wall_length-barrier)
     else:
       draw_barrier(barrier)
# draw the barrier
       draw_door(door - barrier)
       maze_writer.forward(wall_length - door - path_width*2)
 

# TODO: in order for the maze runner to move 
# you should use onkeypress function 
# so when you hit the keys, the turtle will perform that action 
wn = trtl.Screen()
wn.onkeypress(go_up, 'Up')
wn.onkeypress(go_down, 'Down')
wn.onkeypress(go_left, 'Left')
wn.onkeypress(go_right, 'Right')
wn.onkeypress(go_runner, 'w')
wn.listen()

# hide the turtle after
maze_writer.hideturtle()

# configuration for maze timer 
counter = trtl.Turtle()
counter.hideturtle() 
time_up = False 
timer = 0 
font_setup = ("Arial",20,"normal")

# Define function to set a timer for the game 
def maze_timer(): 
    global timer, time_up
    counter.clear()
    if timer <= 0:
        counter.write("Timer:",font = font_setup)  
        timer += 1 
        timer_up = True 
    else: 
        counter.write


    

    





 
 
# Keep the program running without closing
wn = trtl.Screen()
wn.ontimer(maze_timer)
wn.mainloop()