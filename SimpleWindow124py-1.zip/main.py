#   a214_simple_window1.py
#   A program creates a window on your screen using Tkinter.
# Author: Vivek Kasireddy 
# imports tk from library 
import tkinter as tk


#----Functions----# 
# TODO: define a function to add the functionality of the button 
def test_my_button():
    frame_auth.tkraise()
#TODO: Use get method of ent_password when the button is pressed, and store result
    password = ent_password.get()
    
#TODO: Configure the label in frame_auth to display the password
    lbl_frameauth.config(text=password)

# main window
root = tk.Tk()
root.wm_geometry("200x200")
root.title("Authorization")
 
# create empty frame
frame_login = tk.Frame(root)
frame_login.grid(row=0,column=0,sticky="news")

# create label widget
# username
lbl_username = tk.Label(frame_login, text='Username:',font="Ariel")
lbl_username.pack()
# entering the username
ent_username = tk.Entry(frame_login, bd=3)
ent_username.pack(pady=5)
 
# password
lbl_password = tk.Label(frame_login,text="Password:",font="Ariel")
lbl_password.pack()
# entering the password
ent_password = tk.Entry(frame_login, bd=3, show='*')
ent_password.pack(pady=5)


# login button after the username and passwrod is added
button = tk.Button(frame_login, text='Sign In', command=test_my_button)
button.pack()

# set what happens when the Sign In button is clicked 
# initiate the functionality of the button 
frame_auth = tk.Frame(root)
frame_auth.grid(row=0,column=0,sticky="news")

# create label fr frame_auth 
lbl_frameauth = tk.Label(frame_auth, background="red" ,font="Ariel")
lbl_frameauth.pack()


frame_login.tkraise()

frame_blue = tk.Frame(root,width=200,height=100,background='blue')
frame_login.grid(row=0,column=0,sticky="news")


root.mainloop()

