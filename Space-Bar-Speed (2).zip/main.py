# Should we Play a Game - Activity 1.2.5.
# Authors:  Vivek Kasireddy, Alekhya Paripally,Blanca Schaller
# Date: 12/17/2021

#---Import Statements---# ----------------------

# Import turtle to initiate the functions
import turtle as trtl
# Import leaderboard from the library

#----- Game Configurations -----#

# ask the user to input their name to display the message and start the game
player_name = input("Please enter your name: ")

wn = trtl.Screen()
#wn.addshape(bunny_image)
#wn.addshape(cheetah_image)
##wn.addshape(horse_image)
#wn.addshape(turtle_image)

score = 0
timer_up = False
font_setup = ("Times New Roman", 50, 'bold')

# Configurations for displaying a Welome message for the player
welcome_turtle = trtl.Turtle()
welcome_turtle.hideturtle()
welcome_turtle.color('dark blue')

# Configurations for the score keeper of the program
# configurations for space bar clicker
score_keeper = trtl.Turtle()
score_keeper.shape("circle")
score_keeper.color("white")
score_keeper.hideturtle()
score_keeper.penup()
score_keeper.goto(-30 ,0)
score_keeper.pendown()


# ----- Functions ----- #
# TODO: Define a function to display the welcome message
# The welcome message should include the name of the player
#def spacebar_clicker():
def welcome_player(player_name):
    welcome_turtle.penup()
    welcome_turtle.goto(0,125)
    welcome_turtle.write("Welcome," + " " + player_name + " " + "to Speedy Space Bar Clicker!", align="center", font=("Times New Roman", 15, 'bold'))


# TODO: You want to initiate a timer for the program
# configuration for the timer
counter = trtl.Turtle()
counter.hideturtle()  #Hide the turtle so only its text will display
timer = 10  #Initial value for the timer, 0 seconds
counter_interval = 1000  #1000 represents 1 second

#Give the counter its defined positions
counter.penup()
counter.goto(-100,-150)
counter.color("purple")
# Define function to set a timer for the game
#def increase_timer():
#global timer
#Define a function to stop the timer


def countdown():
    global timer, timer_up
    counter.clear()
    if timer <= 0:
        counter.write("Time's Up", font=("Times New Roman", 30, 'bold'))
        timer_up = True
    else:
        counter.write("Timer: " + str(timer),
                      font=("Times New Roman", 30, 'bold'))
        timer -= 1
        counter.getscreen().ontimer(countdown, counter_interval)


# TODO: define a function for clicking the space bar
# An onkeypress function would be called to initiate this function
# Also make the program stop when the timer runs out
# This means the player should be able to see the count of the number of times
# the space has been clicked bease the timer ran out
# TODO define a function for the score
# the score is the number of space bar clicks
# it has to update every single time the spae bar is clicked
def update_score():
    global score
    if timer > 0:
        score += 1
        score_keeper.clear()
        score_keeper.write(score, font=font_setup)
    else:
        score_keeper.clear()
        score_keeper.goto(0,0)
        score_keeper.write("Your final score is:", 
         align="center",font=("Times New Roman", 20, 'bold'))
# initiate a function for displaying the final score 
        score_keeper.penup()
        score_keeper.goto(150,0)
        score_keeper.color("red")
        score_keeper.write(score,font=("Times New Roman", 20, 'bold'))
        score_keeper.pendown()

# hide the turtle once program is done 
score_keeper.hideturtle()
        
# ----- Events ----- # ---------------------------------
wn = trtl.Screen()
# Set the color of the background
wn.bgcolor("skyblue")
#wn.addshape(turtle_image)

# Display the "Welcome player" message on the screen
welcome_player(player_name)

# Start and control the timer
wn.ontimer(countdown, counter_interval)

# initiate the onkeypress function for the space bar
wn.onkeypress(update_score, "space")

# Keep the program running without closing
wn.listen()
wn.mainloop()