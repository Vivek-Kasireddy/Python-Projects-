import turtle as trtl
import random as rand

#-----setup-----
# Store the file name of your shape
apple_image = "apple.gif" 


# Create a display for the game and define its demensions 
wn = trtl.Screen()
wn.setup(width=1.0, height=1.0)

# Make the screen aware of the new file
wn.bgpic("background.gif")
wn.addshape(apple_image) 

#-----game configurations
# list for the aplhabet , starting with the top row going down
letters = ["Q","W","E","R","T","Y","U","I","O","P"]


#Create lists to track each apple and their corresponding letters
apple_list = []
apple_letters = []
num_apples = 5

# Set the number apples present on display 
for i in range(num_apples): 
  apple = trtl.Turtle()
  apple_list.append(apple)
  apple_letters.append(rand.choice(letters))

#----- Functions-----
#TODO Iterate over the numbers from 0 to the number of apples, creating that many turtles
# calling your function that resets the apples by giving them a new random location
# add the new apples to a list of apples to be used in the rest of the program.
# The loop below executes the correct number of times by using the range() function
# to create a list of numbersdef draw_apple(index): 
def draw_apple(index):
  global apple_letters
  apple_list[index].penup()
  apple_list[index].shape(apple_image)
  wn.tracer(False)
  apple_list[index].setx(rand.randint(-175,175))
  apple_list[index].sety(rand.randint(-25,100))

  apple_list[index].sety(apple_list[index].ycor()-35)
  apple_list[index].color("white")
  apple_list[index].write(apple_letters[index], align = "center",font = ("Arial",40, "bold"))
  apple_list[index].sety(apple_list[index].ycor()+35)
  apple_list[index].showturtle()
  wn.tracer(True)
  wn.update()

# function to drop the apple
def drop_apple(index):
  apple_list[index].penup()
  apple_list[index].clear()
  apple_list[index].sety(-150)
  apple_list[index].hideturtle()
  apple_letters[index] = rand.choice(letters)
  draw_apple(index)


#TODO define a function per letter that you will use in your program. Each function should check
# to see if the given letter is in the list of letters; if it is, it should drop the corresponding
# apple

def q_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'Q': 
      drop_apple(i)

def w_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'W': 
      drop_apple(i)

def e_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'E': 
      drop_apple(i)

def r_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'R': 
      drop_apple(i)

def t_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'T': 
      drop_apple(i)


def y_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'Y': 
      drop_apple(i)


def u_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'U': 
      drop_apple(i)


def i_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'I': 
      drop_apple(i)


def o_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'O': 
      drop_apple(i)


def p_clicked():
  for i in range(num_apples):
    if apple_letters[i] == 'P': 
      drop_apple(i)


# ----- function calls -----
for i in range(num_apples): 
  draw_apple(i)

#TODO define a function per letter that you will use in your program. Each function should check
# to see if the given letter is in the list of letters; if it is, it should drop the corresponding
# apple.
wn.onkeypress(q_clicked, 'q')
wn.onkeypress(w_clicked, 'w')
wn.onkeypress(e_clicked, 'e')
wn.onkeypress(r_clicked, 'r')
wn.onkeypress(t_clicked, 't')
wn.onkeypress(y_clicked, 'y')
wn.onkeypress(u_clicked, 'u')
wn.onkeypress(i_clicked, 'i')
wn.onkeypress(o_clicked, 'o')
wn.onkeypress(p_clicked, 'p')

# function is only done when the keys are pressed 
wn.listen()

# keep the display running without closing
wn.mainloop()